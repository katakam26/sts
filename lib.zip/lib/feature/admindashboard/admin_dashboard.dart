import 'package:flutter/material.dart';
import 'package:sts/feature/admindashboard/widgets/attendance_overview_widget.dart';
import 'package:sts/feature/admindashboard/widgets/fleet_monitoring_widget.dart';
import 'package:sts/feature/admindashboard/widgets/fleet_status_section_widget.dart';
import 'package:sts/feature/admindashboard/widgets/my_children_section_widget.dart';
import 'package:sts/feature/admindashboard/widgets/quick_actions_section_widget.dart';
import 'package:sts/feature/admindashboard/widgets/sdmin_feader_widget.dart';
import 'package:sts/feature/admindashboard/widgets/stats_row_widget.dart';
import 'package:sts/feature/admindashboard/widgets/student_statistics_section_widget.dart';
import 'package:sts/feature/admindashboard/widgets/vehicle_status_section_widget.dart';


import '../../utils/app_colors.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      body: SingleChildScrollView(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: screenHeight * 0.02),

                // Header
                const AdminHeaderWidget(),

                SizedBox(height: screenHeight * 0.025),

                // Stats Row
                const StatsRowWidget(),

                SizedBox(height: screenHeight * 0.025),

                // Fleet Monitoring Card
                const FleetMonitoringWidget(),

                SizedBox(height: screenHeight * 0.025),

                // Vehicle Status Section
                const VehicleStatusSectionWidget(),

                SizedBox(height: screenHeight * 0.025),

                // Student Statistics Section
                const StudentStatisticsSectionWidget(),

                SizedBox(height: screenHeight * 0.025),

                // Attendance Overview
                const AttendanceOverviewWidget(),

                SizedBox(height: screenHeight * 0.025),

                // Quick Actions (3 in a row)
                const QuickActionsSectionWidget(),

                SizedBox(height: screenHeight * 0.025),

                // Fleet Status List
                const FleetStatusSectionWidget(),

                SizedBox(height: screenHeight * 0.025),

                //My Children List
                const MyChildrenSectionWidget(),
                SizedBox(height: screenHeight * 0.025),
              ],
            ),
          ),
        ),
      ),
    );
  }
}