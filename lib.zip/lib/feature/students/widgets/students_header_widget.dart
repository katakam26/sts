import 'package:flutter/cupertino.dart';

import '../../../utils/app_colors.dart';
import '../../../utils/app_font_size.dart';
import '../../../utils/app_font_weight.dart';

class StudentsHeaderWidget extends StatelessWidget {
  const StudentsHeaderWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Students',
          style: TextStyle(
            fontSize: AppFontSize.h3(context),
            fontWeight: AppFontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
        SizedBox(height: screenWidth * 0.01),
        Text(
          '12 students',
          style: TextStyle(
            fontSize: AppFontSize.text3(context),
            fontWeight: AppFontWeight.regular,
            color: AppColors.textSecondary,
          ),
        ),
      ],
    );
  }
}