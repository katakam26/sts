import 'package:flutter/material.dart';

import 'feature/admindashboard/admin_dashboard.dart';
import 'feature/profile/profile_screen.dart';
import 'feature/routes/routes_screen.dart';
import 'feature/students/students_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: .fromSeed(seedColor: Colors.deepPurple),
      ),
      debugShowCheckedModeBanner: false,
      home: const AdminDashboardScreen(),
    );
  }
}

